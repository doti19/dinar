# Dinar
A backend for the ...


Copyright (c) [2024] [Saminas Hagos Gigar]

All rights reserved.

This code or any portion thereof may not be reproduced or used in any manner whatsoever without the express written permission of the author.
