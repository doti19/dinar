const IMAGES_FOLDER_PATH = '/public/images/';
module.exports = {
  IMAGES_FOLDER_PATH
};